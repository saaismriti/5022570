/**
 * 
 */
/**
 * 
 */
module ObserverPatternExample {
}