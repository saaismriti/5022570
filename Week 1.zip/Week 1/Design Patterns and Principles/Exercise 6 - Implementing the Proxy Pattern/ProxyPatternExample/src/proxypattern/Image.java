package proxypattern;

public interface Image {
    void display();
}
